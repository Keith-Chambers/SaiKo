/****************************************************************************
** Meta object code from reading C++ file 'audioplayer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../SaiKo/audioplayer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'audioplayer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_AudioPlayer_t {
    QByteArrayData data[17];
    char stringdata0[196];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AudioPlayer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AudioPlayer_t qt_meta_stringdata_AudioPlayer = {
    {
QT_MOC_LITERAL(0, 0, 11), // "AudioPlayer"
QT_MOC_LITERAL(1, 12, 19), // "playPositionChanged"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 16), // "isPlayingChanged"
QT_MOC_LITERAL(4, 50, 11), // "setPlaylist"
QT_MOC_LITERAL(5, 62, 8), // "playlist"
QT_MOC_LITERAL(6, 71, 8), // "nextSong"
QT_MOC_LITERAL(7, 80, 8), // "prevSong"
QT_MOC_LITERAL(8, 89, 12), // "getIsPlaying"
QT_MOC_LITERAL(9, 102, 12), // "setIsPlaying"
QT_MOC_LITERAL(10, 115, 9), // "isPlaying"
QT_MOC_LITERAL(11, 125, 15), // "setPlayPosition"
QT_MOC_LITERAL(12, 141, 3), // "pos"
QT_MOC_LITERAL(13, 145, 15), // "getPlayPosition"
QT_MOC_LITERAL(14, 161, 11), // "togglePause"
QT_MOC_LITERAL(15, 173, 9), // "stopAudio"
QT_MOC_LITERAL(16, 183, 12) // "playPosition"

    },
    "AudioPlayer\0playPositionChanged\0\0"
    "isPlayingChanged\0setPlaylist\0playlist\0"
    "nextSong\0prevSong\0getIsPlaying\0"
    "setIsPlaying\0isPlaying\0setPlayPosition\0"
    "pos\0getPlayPosition\0togglePause\0"
    "stopAudio\0playPosition"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AudioPlayer[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       2,   90, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   69,    2, 0x06 /* Public */,
       3,    1,   72,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    1,   75,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
       6,    0,   78,    2, 0x02 /* Public */,
       7,    0,   79,    2, 0x02 /* Public */,
       8,    0,   80,    2, 0x02 /* Public */,
       9,    1,   81,    2, 0x02 /* Public */,
      11,    1,   84,    2, 0x02 /* Public */,
      13,    0,   87,    2, 0x02 /* Public */,
      14,    0,   88,    2, 0x02 /* Public */,
      15,    0,   89,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Double,    2,
    QMetaType::Void, QMetaType::Bool,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::QStringList,    5,

 // methods: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void, QMetaType::Double,   12,
    QMetaType::Double,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      16, QMetaType::Double, 0x00495103,
      10, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       0,
       1,

       0        // eod
};

void AudioPlayer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        AudioPlayer *_t = static_cast<AudioPlayer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->playPositionChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 1: _t->isPlayingChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->setPlaylist((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 3: _t->nextSong(); break;
        case 4: _t->prevSong(); break;
        case 5: { bool _r = _t->getIsPlaying();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 6: _t->setIsPlaying((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->setPlayPosition((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 8: { double _r = _t->getPlayPosition();
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 9: _t->togglePause(); break;
        case 10: _t->stopAudio(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (AudioPlayer::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AudioPlayer::playPositionChanged)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (AudioPlayer::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AudioPlayer::isPlayingChanged)) {
                *result = 1;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        AudioPlayer *_t = static_cast<AudioPlayer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = _t->getPlayPosition(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->getIsPlaying(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        AudioPlayer *_t = static_cast<AudioPlayer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setPlayPosition(*reinterpret_cast< double*>(_v)); break;
        case 1: _t->setIsPlaying(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject AudioPlayer::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_AudioPlayer.data,
      qt_meta_data_AudioPlayer,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *AudioPlayer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AudioPlayer::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_AudioPlayer.stringdata0))
        return static_cast<void*>(const_cast< AudioPlayer*>(this));
    return QObject::qt_metacast(_clname);
}

int AudioPlayer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void AudioPlayer::playPositionChanged(double _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void AudioPlayer::isPlayingChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
